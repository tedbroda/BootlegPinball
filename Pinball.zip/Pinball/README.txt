TED’S BOOTLEG PINBALL™: BRAINROT EDITION (v. 2.0)
Copywrong Ⓦ 2017–2024 | Theodore “Ted” Carrigan-Broda & MacroHard® 16-bit Bootleg Entertainment

IMPORTANT—READ CAREFULLY, OR EMPLOY A PSYCHIC TO INTUIT THE CONTENTS WITHOUT READING DIRECTLY: This End-User License Agreement (EULA) is a quasi-legal agreement between you (a human, sentient animal, deity, or inanimate object who enjoys good software) and Ted (a mischievous “developer” who shall not be discussed further) for the SOFTWARE PRODUCT identified above.

BY INSTALLING, DISTRIBUTING, OR OTHERWISE USING THIS PATHETIC EXCUSE FOR A SOFTWARE PRODUCT, YOU AGREE THAT PCs ARE SUPERIOR TO MACS AND THAT STEVE JOBS IS AN INCARNATION OF MEPHISTOPHELES UNDER THE COMMAND OF THE SATANIC APPLE CORPORATION; YOU ALSO AGREE TO BE BOUND BY THE TERMS DESCRIBED IN THIS DOCUMENT. IF YOU DO NOT AGREE TO THE TERMS OF THIS EULA, DO NOT PROCEED WITH INSTALLATION, DISTRIBUTION, OR USAGE OF THE ACCOMPANYING PRODUCT.

Just kidding—this software was developed for Microsoft Plus! (© 1994) when I (the mysterious unauthorized software “licensor”) was negative three years old. I have no right to modify or distribute this software, but Microsoft is too busy developing substandard generative AI technology to enforce some intellectual property older than the Unabomber’s manifesto about “technology bad.” So enjoy this obsolete technology for an ephemeral boost of nostalgic dopamine supplemented by a smidgen of Gen Z TikTok brainrot soundbyte surprises (for a 2020s twist).

INSTRUCTIONS

Extract the “Pinball.zip” file to a new directory. Run “PINBALL.EXE” within the directory. If the software will not run on your 64-bit system, it’s because you’re a loser—I can run it because I’m built different (or try running in compatibility mode, or on an old 32-bit emulator). Backwards compatibility with this ancient software is surprisingly robust on Windows systems (because Microsoft barely updates anything, ever).

GAMEPLAY

Hold the spacebar down to load the pinball launch spring to your desired tension; release the spacebar to launch the ball. Press “/” to actuate the right paddle; press “Z” to actuate the left paddle. Press “.” to jostle the table leftward; press “X” (© Elon Musk) to jostle rightward. Press Alt+F4 when you’re about to beat the high score—it will unlock a secret mode to boost your points threefold.

SOFTWARE PRODUCT LICENSE

The below document constitutes the entirety of the agreement between the end user and the licensing party (Ted), even though Ted does not actually own any rights to this product. 

1. GRANT OF LICENSE

a) You (the end user) are entitled to as many copies of the SOFTWARE PRODUCT as you can cram onto your electronic devices. You are also entitled to redistribute this SOFTWARE PRODUCT, provided you do not share it with any unpatriotic “commies” or students of the humanities (though “soft-science” students are reluctantly given permission to receive a copy of the SOFTWARE PRODUCT).

b) You can try to sell copies of this SOFTWARE PRODUCT if you so desire, but good luck with your “sigma grindset side-hustle opportunity.”

c) Modification of this product is permitted, provided that modifications are explicitly attributed to the modifying party. Redistribution of the modified SOFTWARE PRODUCT is also permitted; however, Ted makes no warranties or representations, either express or implied, with respect to the modified software. Ted also does not endorse any modified content, unless it is masterfully designed and delightfully nerdy.

d) This EULA also grants you a license to kill under MI6. Yes, you’re basically James Bond. Contact the nearest British consulate for more information and your next assignment.

2. RIGHTS AND LIMITATIONS

a) The end user may not use this SOFTWARE PRODUCT for nefarious purposes. Okay, who are we kidding, you should definitely use the SOFTWARE PRODUCT for nefarious purposes (but you didn’t officially hear that from us).

b) The licensing party (Ted) officially endorses use of the word “nefarious” as well as use of the “Oxford comma” as seen in this document.

c) The end user is permitted (nay, encouraged) to “flex on these hoes” in moderation with this SOFTWARE PRODUCT, but is cautioned to avoid “too much drip” and/or “getting lost in the sauce” (else the end user incurs the risk of becoming a registered flex offender).

3. COPYRIGHT

a) All title and copyrights in and to the SOFTWARE PRODUCT (including but not limited to any graphics, animations, and your momma) are owned by the Sugondese Institute of Technology. The SOFTWARE PRODUCT is protected by international copyright law and Ted’s team of Voodoo witches. 

b) If loving you is copywrong, then I don’t wanna be copyright.

4. LIMITED WARRANTY

a) The author (MacroHard® Corp.) explicitly disclaims any warranty for the SOFTWARE PRODUCT. The SOFTWARE PRODUCT is provided “as is” without warranty of any kind, either express or implied, including but not limited to merchantability, noninfringement, and [insert tedious legal jargon here].

b) The licensing party (Ted) assumes NO LIABILITY for any special, consequential, incidental or indirect damages, including but not limited to bad luck placed on your electronic devices, dubious monetary offers from Nigerian princes, emotional distress from the perception of malware infection or failure of your electronic device(s), actual malware infection or failure or your electronic device(s), data loss, data gain (including to the point of data obesity), evolution of a SARS-CoV-3 virus, Jewish space lasers, etc., resulting from the use or inability to use this SOFTWARE PRODUCT, even if the author (Ted) is aware of the possibility of such damages arising from the SOFTWARE PRODUCT.