GAMEMASTER TED has substituted some of the original WAV & MIDI sound effects in the game directory with new "brainrot" sound effects with the same filename for shock value/humorous effect. To restore the original sound effects, copy the original files from this directory to the game directory, overwriting the substitute files.

To match original format, encode sound effects as 88kbps mono unsigned 8-bit PCM WAV files (sample rate: 11.025 kHz)

To save in this encoding in Audacity 2.3.1, set "Project Rate (Hz)" to 11025. Click "File" > "Export" > "Export as WAV" > "Save as type": "Other uncompressed files" > "Header": "WAV (Microsoft)", "Encoding": "Unsigned 8-bit PCM"

Copywrong Ⓦ 2021-2024 | Theodore Carrigan-Broda & MacroHard 16-bit Bootleg Entertainment (2021)